export declare const comparePasswords: (password: any, hash: any) => any;
export declare const hashPassword: (password: any) => any;
export declare const createJWT: (user: any) => any;
export declare const protect: (req: any, res: any, next: any) => void;
