export declare const createNewUser: (req: any, res: any, next: any) => Promise<void>;
export declare const signin: (req: any, res: any) => Promise<void>;
